<?php

ob_start();  

define('API_URL', 'https://anhcode.io.vn/apiv1/garena/api.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    ob_clean();  
    
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $response = ['success' => false, 'message' => 'Vui lòng nhập đầy đủ thông tin'];
    
    if (!empty($username) && !empty($password)) {
        $url = API_URL . '?username=' . urlencode($username) . '&password=' . urlencode($password);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $result = curl_exec($ch);
        curl_close($ch);
        
        if ($result) {
            $start = strpos($result, '{');
            if ($start !== false) {
                $json = substr($result, $start);
                $data = json_decode($json, true);
                
                if ($data && isset($data['success']) && $data['success'] === true) {
                    $p = $data['pipeline'] ?? [];
                    $kt = $data['kt_data'] ?? [];
                    $wk = $data['weekly_data'] ?? [];
                    $skins = $data['parsed_skins'] ?? [];
                    $heroes = $data['unique_heroes'] ?? [];
                    $sss = $data['sss_skins'] ?? [];
                    $anime = $data['anime_skins'] ?? [];
                    $ss = $data['ss_skins'] ?? [];
                    
                    $player = is_array($wk) ? ($wk['player_info'] ?? []) : [];
                    $rankConfig = is_array($wk) ? ($wk['rank_config'] ?? []) : [];
                    $rank = $player['rank'] ?? 0;
                    $rankName = $rankConfig[(string)$rank]['name'] ?? 'Chưa có';
                    
                    $isBanned = ($kt['banned'] ?? 'NO') === 'YES';
                    $banEnd = $kt['ban_end_time'] ?? '';
                    
                    $heroSkins = [];
                    foreach ($skins as $s) {
                        $name = $s['hero_name'] ?? '';
                        if ($name) {
                            if (!isset($heroSkins[$name])) {
                                $heroSkins[$name] = [
                                    'name' => $name,
                                    'avatar' => $s['hero_avatar'] ?? '',
                                    'skins' => []
                                ];
                            }
                            $heroSkins[$name]['skins'][] = [
                                'name' => $s['skin_name'] ?? 'Skin',
                                'tier' => $s['tier'] ?? 'Thường',
                                'avatar' => $s['skin_avatar'] ?? ''
                            ];
                        }
                    }
                    ksort($heroSkins);
                    
                    $tier = 'Thường';
                    $badge = 'normal';
                    if ($isBanned) {
                        $tier = 'BỊ BAN';
                        $badge = 'ban';
                    } elseif (count($sss) > 0) {
                        $tier = 'ACC XỊN (SSS)';
                        $badge = 'xin';
                    } elseif (count($anime) > 0) {
                        $tier = 'ACC NGON (Anime)';
                        $badge = 'xin';
                    } elseif (count($ss) > 0) {
                        $tier = 'ACC KHÁ (SS)';
                        $badge = 'xin';
                    } elseif (count($skins) > 10) {
                        $tier = 'ACC THƯỜNG';
                        $badge = 'normal';
                    }
                    
                    $response = [
                        'success' => true,
                        'username' => $p['username'] ?? '',
                        'uid' => $p['garena_uid'] ?? '',
                        'ingame' => $kt['name'] ?? $player['name'] ?? '',
                        'player_uid' => $player['player_uid'] ?? '',
                        'rank' => $rankName,
                        'stars' => $kt['rank_stars'] ?? 0,
                        'banned' => $isBanned,
                        'ban_end' => $banEnd,
                        'level' => $kt['level'] ?? 30,
                        'register' => $kt['register_time'] ?? '',
                        'total_skins' => count($skins),
                        'total_heroes' => count($heroes),
                        'sss' => count($sss),
                        'anime' => count($anime),
                        'ss' => count($ss),
                        'tier' => $tier,
                        'badge' => $badge,
                        'sso' => $p['sso_key'] ?? '',
                        'access' => $p['access_token'] ?? '',
                        'session' => $p['session_token'] ?? '',
                        'openid' => $p['open_id'] ?? '',
                        'top_skins' => array_merge($sss, $anime, $ss),
                        'heroes' => array_values($heroSkins),
                        'all_skins_data' => $skins,
                        'sss_list' => $sss,
                        'anime_list' => $anime,
                        'ss_list' => $ss
                    ];
                    
                } else {
                    $response['message'] = $data['message'] ?? $data['error'] ?? 'Đăng nhập thất bại';
                }
            } else {
                $response['message'] = 'Dữ liệu trả về không hợp lệ';
            }
        } else {
            $response['message'] = 'Không thể kết nối đến API Server';
        }
    }
    

    header('Content-Type: application/json');
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit;
}



?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    :root { 
        --main: #00ff88;
        --main-dark: #00cc6a;
        --main-glow: rgba(0, 255, 136, 0.25);
        --bg-card: #111827;
        --bg-input: #1f2937;
        --border-glass: rgba(255, 255, 255, 0.06);
        --gold: #f59e0b;
        --pink: #ec4899;
        --blue: #38bdf8;
        --red: #ef4444;
        --text-secondary: #94a3b8;
        --bg-hover: rgba(0, 255, 136, 0.08);
    }

    .check-container { padding: 40px 0; }
    
    .check-card {
        background: var(--bg-card);
        border: 1px solid var(--border-glass);
        border-radius: 20px;
        padding: 32px 28px;
        max-width: 820px;
        margin: 0 auto;
        position: relative;
        overflow: hidden;
        transition: 0.3s;
    }
    .check-card:hover {
        border-color: rgba(0, 255, 136, 0.2);
        box-shadow: 0 0 40px rgba(0, 255, 136, 0.05);
    }
    .check-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 10%;
        right: 10%;
        height: 2px;
        background: linear-gradient(90deg, transparent, var(--main), transparent);
        box-shadow: 0 0 20px var(--main);
    }

    .check-title {
        text-align: center;
        margin-bottom: 28px;
    }
    .check-title h2 {
        color: #fff;
        font-weight: 800;
        font-size: 22px;
        letter-spacing: 0.5px;
    }
    .check-title h2 i {
        color: var(--main);
        margin-right: 10px;
        text-shadow: 0 0 20px var(--main-glow);
    }
    .check-title p {
        font-size: 13px;
        color: var(--text-secondary);
        margin-top: 4px;
    }

    .form-group {
        margin-bottom: 18px;
    }
    .form-group label {
        display: block;
        font-size: 13px;
        font-weight: 700;
        color: #e2e8f0;
        margin-bottom: 6px;
        letter-spacing: 0.3px;
    }
    .form-group label i {
        color: var(--main);
        margin-right: 6px;
    }
    .input-wrapper {
        position: relative;
    }
    .input-wrapper i {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #64748b;
        font-size: 15px;
    }
    .form-control {
        width: 100%;
        padding: 14px 16px 14px 44px;
        background: var(--bg-input);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        color: #fff;
        font-size: 14px;
        outline: none;
        transition: all 0.3s ease;
        font-weight: 500;
    }
    .form-control:focus {
        border-color: var(--main);
        box-shadow: 0 0 25px var(--main-glow);
        background: rgba(31, 41, 55, 0.95);
    }
    .form-control::placeholder {
        color: #64748b;
    }
    .toggle-password {
        position: absolute;
        right: 50px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #64748b;
        cursor: pointer;
        font-size: 16px;
        padding: 4px;
    }
    .toggle-password:hover {
        color: #fff;
    }

    .btn-check {
        width: 100%;
        padding: 16px;
        background: linear-gradient(90deg, var(--main), var(--main-dark), #00bdff);
        border: none;
        border-radius: 12px;
        color: #000;
        font-size: 15px;
        font-weight: 800;
        letter-spacing: 1px;
        text-transform: uppercase;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        box-shadow: 0 8px 30px rgba(0, 255, 136, 0.3);
    }
    .btn-check:hover:not(:disabled) {
        transform: translateY(-3px);
        box-shadow: 0 12px 40px rgba(0, 255, 136, 0.5);
        filter: brightness(1.05);
    }
    .btn-check:disabled {
        opacity: 0.5;
        cursor: not-allowed;
        transform: none !important;
    }
    .btn-check .spinner {
        display: none;
        width: 20px;
        height: 20px;
        border: 2px solid rgba(0, 0, 0, 0.15);
        border-top: 2px solid #000;
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }
    .btn-check.loading .spinner {
        display: inline-block;
    }
    .btn-check.loading .btn-text {
        display: none;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    @keyframes slideDown {
        from { opacity: 0; max-height: 0; }
        to { opacity: 1; max-height: 800px; }
    }

    #result {
        display: none;
        margin-top: 24px;
        animation: fadeIn 0.4s ease;
    }

    .result-card {
        background: rgba(17, 24, 39, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 16px;
        padding: 18px 20px;
        margin-bottom: 14px;
        transition: 0.3s;
    }
    .result-card:hover {
        border-color: rgba(0, 255, 136, 0.1);
    }
    .result-card .row {
        display: flex;
        justify-content: space-between;
        padding: 7px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.03);
        font-size: 13px;
    }
    .result-card .row:last-child {
        border-bottom: none;
    }
    .result-card .label {
        color: var(--text-secondary);
        font-weight: 500;
    }
    .result-card .value {
        color: #fff;
        font-weight: 600;
        text-align: right;
        max-width: 60%;
        word-break: break-all;
    }
    .result-card .value.highlight { color: var(--main); }
    .result-card .value.gold { color: var(--gold); }
    .result-card .value.green { color: var(--main); }
    .result-card .value.red { color: var(--red); }
    .result-card .value.pink { color: var(--pink); }
    .result-card .value.blue { color: var(--blue); }

    .badge {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .badge.safe { background: rgba(0, 255, 136, 0.15); color: var(--main); border: 1px solid rgba(0, 255, 136, 0.2); }
    .badge.ban { background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2); }
    .badge.xin { background: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.2); }
    .badge.normal { background: rgba(255, 255, 255, 0.05); color: #94a3b8; border: 1px solid rgba(255, 255, 255, 0.06); }


    .category-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        width: 100%;
        margin: 4px 0;
    }
    .category-item {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 10px;
        padding: 8px 6px;
        cursor: pointer;
        transition: all 0.25s ease;
        text-align: center;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 1px;
    }
    .category-item:hover {
        background: var(--bg-hover);
        border-color: var(--main);
        transform: translateY(-2px);
    }
    .category-item .cat-label {
        font-size: 10px;
        color: #94a3b8;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    .category-item .cat-count {
        font-size: 18px;
        font-weight: 800;
        color: #fff;
    }
    .category-item .cat-icon {
        font-size: 16px;
    }
    .category-item.sss .cat-count { color: #fbbf24; }
    .category-item.anime .cat-count { color: #f472b6; }
    .category-item.ss .cat-count { color: var(--blue); }
    .category-item.normal .cat-count { color: #94a3b8; }
    .category-item.all .cat-count { color: var(--main); }
    .category-item.hero .cat-count { color: #60a5fa; }
    
    .category-item.active {
        border-color: var(--main) !important;
        background: var(--bg-hover) !important;
        box-shadow: 0 0 30px rgba(0, 255, 136, 0.08);
    }


.skin-list-container {
    display: none;
    margin-top: 12px;
    padding: 12px 14px;
    background: rgba(0, 0, 0, 0.35);
    border: 1px solid rgba(0, 255, 136, 0.12);
    border-radius: 12px;
    max-height: 450px;
    overflow-y: auto;
}
.skin-list-container.open {
    display: block;
    animation: slideDown 0.3s ease;
}


.skin-list-container .skin-item {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 10px 12px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
    transition: all 0.25s ease;
    border-radius: 8px;
}
.skin-list-container .skin-item:hover {
    background: rgba(0, 255, 136, 0.06);
    transform: translateX(4px);
}
.skin-list-container .skin-item:last-child {
    border-bottom: none;
}


.skin-list-container .skin-item .skin-avatar {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid rgba(255, 255, 255, 0.08);
    background: rgba(255, 255, 255, 0.03);
    flex-shrink: 0;
    transition: all 0.3s ease;
}
.skin-list-container .skin-item:hover .skin-avatar {
    border-color: var(--main);
    transform: scale(1.05);
    box-shadow: 0 0 20px rgba(0, 255, 136, 0.15);
}


.skin-list-container .skin-item .skin-info {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 3px;
    min-width: 0;
}
.skin-list-container .skin-item .skin-name {
    font-size: 14px;
    font-weight: 600;
    color: #f1f5f9;
    line-height: 1.3;
}
.skin-list-container .skin-item .skin-hero {
    font-size: 11px;
    color: var(--text-secondary);
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 4px;
}
.skin-list-container .skin-item .skin-hero i {
    font-size: 10px;
    color: var(--main);
}


.skin-list-container .skin-item .skin-tier {
    font-size: 10px;
    font-weight: 700;
    padding: 3px 12px;
    border-radius: 20px;
    flex-shrink: 0;
    letter-spacing: 0.3px;
    text-transform: uppercase;
}
.skin-tier.SSS { background: rgba(245, 158, 11, 0.2); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.25); }
.skin-tier.Anime { background: rgba(236, 72, 153, 0.2); color: #f472b6; border: 1px solid rgba(236, 72, 153, 0.25); }
.skin-tier.SS { background: rgba(56, 189, 248, 0.2); color: var(--blue); border: 1px solid rgba(56, 189, 248, 0.25); }
.skin-tier.Thường { background: rgba(255, 255, 255, 0.05); color: #94a3b8; border: 1px solid rgba(255, 255, 255, 0.08); }


.skin-list-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 6px 0 10px 0;
    border-bottom: 2px solid rgba(0, 255, 136, 0.08);
    margin-bottom: 8px;
}
.skin-list-header .title {
    font-weight: 700;
    color: #fff;
    font-size: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.skin-list-header .count {
    font-size: 12px;
    color: #64748b;
    background: rgba(255,255,255,0.05);
    padding: 2px 12px;
    border-radius: 20px;
}

    .hero-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
        gap: 10px;
        margin-top: 12px;
    }
    .hero-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 8px 4px;
        cursor: pointer;
        transition: all 0.25s ease;
    }
    .hero-item:hover {
        border-color: var(--main);
        transform: translateY(-3px);
        box-shadow: 0 4px 20px rgba(0, 255, 136, 0.1);
    }
    .hero-item.active {
        border-color: var(--main);
        background: rgba(0, 255, 136, 0.06);
        box-shadow: 0 0 30px rgba(0, 255, 136, 0.05);
    }
    .hero-item img {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid rgba(255, 255, 255, 0.06);
    }
    .hero-item .hero-name {
        font-size: 10px;
        color: #cbd5e1;
        text-align: center;
        margin-top: 4px;
        font-weight: 600;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 100%;
    }
    .hero-item .skin-count {
        font-size: 9px;
        color: #64748b;
        margin-top: 1px;
    }
    .hero-skins {
        display: none;
        margin-top: 12px;
        padding: 12px 16px;
        background: rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(0, 255, 136, 0.15);
        border-radius: 12px;
    }
    .hero-skins.open {
        display: block;
        animation: fadeIn 0.25s ease;
    }
    .hero-skins .skin-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 6px 0;
        border-bottom: 1px solid rgba(255, 255, 255, 0.03);
    }
    .hero-skins .skin-item:last-child {
        border-bottom: none;
    }
    .hero-skins .skin-item img {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        object-fit: cover;
        border: 1px solid rgba(255, 255, 255, 0.06);
    }
    .hero-skins .skin-item .skin-name {
        flex: 1;
        font-size: 12px;
        font-weight: 500;
        color: #e2e8f0;
    }
    .hero-skins .skin-item .skin-tier {
        font-size: 10px;
        font-weight: 600;
        padding: 2px 10px;
        border-radius: 12px;
    }

    .token-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 8px;
        padding: 8px 12px;
        margin-bottom: 5px;
        font-size: 11px;
        gap: 8px;
    }
    .token-row .token-label {
        color: var(--text-secondary);
        font-weight: 600;
        flex-shrink: 0;
    }
    .token-row .token-value {
        color: var(--main);
        font-family: monospace;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1;
        font-size: 11px;
    }
    .token-row .btn-copy {
        background: rgba(255, 255, 255, 0.06);
        border: none;
        color: #fff;
        padding: 4px 10px;
        border-radius: 5px;
        font-size: 10px;
        cursor: pointer;
        font-weight: 600;
        transition: all 0.2s;
        flex-shrink: 0;
    }
    .token-row .btn-copy:hover {
        background: var(--main);
        color: #000;
    }
    .token-toggle {
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 0;
        border-top: 1px solid rgba(255, 255, 255, 0.05);
        margin-top: 12px;
        color: var(--text-secondary);
        font-size: 12px;
        font-weight: 600;
        transition: color 0.2s;
    }
    .token-toggle:hover {
        color: #fff;
    }
    .token-toggle i {
        transition: transform 0.3s ease;
        font-size: 12px;
    }
    .token-toggle.open i {
        transform: rotate(180deg);
    }
    #tokenDrawer {
        display: none;
        margin-top: 10px;
    }
    #tokenDrawer.open {
        display: block;
    }

    .error-box {
        background: rgba(239, 68, 68, 0.08);
        border: 1px solid rgba(239, 68, 68, 0.2);
        border-radius: 12px;
        padding: 16px 18px;
        color: #fca5a5;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        font-size: 13px;
    }
    .error-box i {
        color: var(--red);
        font-size: 18px;
        margin-top: 2px;
    }
    .error-box .error-title {
        font-weight: 700;
        color: #fff;
        margin-bottom: 2px;
    }

    .hero-section-header {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-secondary);
        font-weight: 600;
        font-size: 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        margin-top: 4px;
    }
    .hero-section-header i {
        color: var(--main);
    }
    .hero-section-header span {
        font-weight: 400;
        font-size: 10px;
        color: #64748b;
    }
    .cat-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
    }
    .cat-header .cat-title {
        font-size: 13px;
        font-weight: 700;
        color: #fff;
    }
    .cat-header .cat-sub {
        font-size: 11px;
        color: var(--text-secondary);
    }

    @media (max-width: 580px) {
        .check-card { padding: 20px 16px; }
        .category-grid { grid-template-columns: repeat(3, 1fr); gap: 6px; }
        .category-item { padding: 6px 4px; }
        .category-item .cat-count { font-size: 15px; }
        .category-item .cat-label { font-size: 9px; }
        .result-card .row { font-size: 12px; flex-wrap: wrap; }
        .result-card .value { max-width: 100%; text-align: left; margin-top: 2px; }
        .hero-grid { grid-template-columns: repeat(auto-fill, minmax(65px, 1fr)); gap: 6px; }
        .hero-item img { width: 40px; height: 40px; }
        .hero-item .hero-name { font-size: 9px; }
    }
    @media (max-width: 400px) {
        .category-grid { grid-template-columns: repeat(2, 1fr); }
    }
</style>

<div class="container check-container">
    <div class="check-card">
        <div class="check-title">
            <h2><i class="fas fa-shield-alt"></i> Xác Thực Tài Khoản</h2>
            <p> </p>
        </div>
        <form id="checkForm">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Tài Khoản / Email / SĐT</label>
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" class="form-control" placeholder="Nhập tài khoản Garena..." required>
                </div>
            </div>
            <div class="form-group">
                <label><i class="fas fa-key"></i> Mật Khẩu</label>
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" class="form-control" placeholder="Nhập mật khẩu..." required>
                    <button type="button" class="toggle-password" onclick="togglePass()">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn-check" id="btnCheck">
                <span class="spinner"></span>
                <span class="btn-text"><i class="fas fa-bolt"></i> Bắt Đầu Quét</span>
            </button>
        </form>
        <div id="result"></div>
    </div>
</div>

<script>
let heroesData = [];
let allSkinsData = [];
let sssList = [];
let animeList = [];
let ssList = [];

function togglePass() {
    const input = document.getElementById('password');
    const icon = document.getElementById('eyeIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

$('#checkForm').submit(function(e) {
    e.preventDefault();
    
    const username = $('#username').val().trim();
    const password = $('#password').val();
    const btn = $('#btnCheck');
    const result = $('#result');
    
    if (!username || !password) {
        Swal.fire({ 
            icon: 'warning', 
            title: 'Thiếu thông tin', 
            text: 'Vui lòng nhập đầy đủ!', 
            background: '#111827', 
            color: '#fff' 
        });
        return;
    }
    
    btn.addClass('loading').prop('disabled', true);
    result.hide().html('');
    
    $.post(window.location.href, { 
        action: 'check', 
        username: username, 
        password: password 
    }, function(data) {
        btn.removeClass('loading').prop('disabled', false);
        
        if (data.success) {
            renderResult(data);
            result.show();
        } else {
            result.html(`
                <div class="error-box">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <div class="error-title">Lỗi:</div>
                        <div>${data.message || 'Đăng nhập thất bại'}</div>
                    </div>
                </div>
            `).show();
        }
    }).fail(function() {
        btn.removeClass('loading').prop('disabled', false);
        result.html(`
            <div class="error-box">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <div class="error-title">Lỗi kết nối</div>
                    <div>Không thể kết nối đến API Server</div>
                </div>
            </div>
        `).show();
    });
});

function renderResult(d) {
    heroesData = d.heroes || [];
    allSkinsData = d.all_skins_data || [];
    sssList = d.sss_list || [];
    animeList = d.anime_list || [];
    ssList = d.ss_list || [];
    
    const badge = d.badge || 'normal';
    const tier = d.tier || 'Thường';
    
    const totalSkins = d.total_skins || 0;
    const sssCount = d.sss || 0;
    const animeCount = d.anime || 0;
    const ssCount = d.ss || 0;
    const normalSkins = totalSkins - sssCount - animeCount - ssCount;
    const totalHeroes = d.total_heroes || 0;
    

let statusHtml = '';
if (d.banned === true) {
    if (d.ban_end && d.ban_end !== '') {
        statusHtml = `
            <span style="color: #f87171; font-weight: 700;">🚫 BỊ BAN</span>
            <br><small style="color:#94a3b8;font-size:11px;">⏰ Hết hạn: ${d.ban_end}</small>
        `;
    } else {
        statusHtml = `
            <span style="color: #f87171; font-weight: 700;">🚫 BỊ BAN</span>
            <br><small style="color:#94a3b8;font-size:11px;">⚠️ Vĩnh viễn</small>
        `;
    }
} else {
    statusHtml = `
        <span style="color: #4ade80; font-weight: 700;">✅ AN TOÀN</span>
        <br><small style="color:#94a3b8;font-size:11px;">🟢 Không bị ban</small>
    `;
}

let html = `
    <div class="result-card">
        <div class="row">
            <span class="label"><i class="fas fa-id-card"></i> Đánh giá</span>
            <span class="value"><span class="badge ${badge}">${tier}</span></span>
        </div>
        <div class="row" style="border-bottom: 2px solid rgba(255,255,255,0.08); padding-bottom: 10px; margin-bottom: 6px;">
            <span class="label"><i class="fas fa-shield-alt"></i> Tình trạng</span>
            <span class="value" style="text-align: right; max-width: 70%;">
                ${statusHtml}
            </span>
        </div>
        

        <div class="row" style="flex-wrap:wrap;padding-bottom:10px;border-bottom:2px solid rgba(0,255,136,0.08);margin-bottom:8px;">
            <span class="label" style="font-weight:700;color:#e2e8f0;width:100%;margin-bottom:6px;">
                <i class="fas fa-layer-group" style="color:var(--main);"></i> Phân loại chi tiết
                <span style="font-size:10px;color:#64748b;font-weight:400;">(Bấm để xem danh sách)</span>
            </span>
            <div class="category-grid">
                <div class="category-item all" onclick="showSkinList('all', ${totalSkins})">
                    <span class="cat-icon">📊</span>
                    <span class="cat-count">${totalSkins}</span>
                    <span class="cat-label">Tất cả</span>
                </div>
                <div class="category-item sss" onclick="showSkinList('sss', ${sssCount})">
                    <span class="cat-icon">⭐</span>
                    <span class="cat-count">${sssCount}</span>
                    <span class="cat-label">SSS</span>
                </div>
                <div class="category-item anime" onclick="showSkinList('anime', ${animeCount})">
                    <span class="cat-icon">🎭</span>
                    <span class="cat-count">${animeCount}</span>
                    <span class="cat-label">Anime</span>
                </div>
                <div class="category-item ss" onclick="showSkinList('ss', ${ssCount})">
                    <span class="cat-icon">💎</span>
                    <span class="cat-count">${ssCount}</span>
                    <span class="cat-label">SS</span>
                </div>
                <div class="category-item hero" onclick="showSkinList('hero', ${totalHeroes})">
                    <span class="cat-icon">👤</span>
                    <span class="cat-count">${totalHeroes}</span>
                    <span class="cat-label">Tướng</span>
                </div>
                <div class="category-item normal" onclick="showSkinList('normal', ${normalSkins})">
                    <span class="cat-icon">👕</span>
                    <span class="cat-count">${normalSkins}</span>
                    <span class="cat-label">Áo Thường</span>
                </div>
            </div>
        </div>
        
        <div id="skinListContainer" class="skin-list-container"></div>
        
        <div class="row">
            <span class="label"><i class="fas fa-user"></i> Tài khoản</span>
            <span class="value highlight">${d.username || 'N/A'}</span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-id-badge"></i> Garena UID</span>
            <span class="value highlight">${d.uid || 'N/A'}</span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-gamepad"></i> Tên Ingame</span>
            <span class="value">${d.ingame || 'N/A'}</span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-hashtag"></i> Player UID</span>
            <span class="value">${d.player_uid || 'N/A'}</span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-trophy"></i> Xếp hạng</span>
            <span class="value gold">🏆 ${d.rank || 'Chưa có'} (${d.stars || 0}★)</span>
        </div>
        <div class="row">
            <span class="label"><i class="fas fa-level-up"></i> Cấp độ</span>
            <span class="value">${d.level || 30}</span>
        </div>
        ${d.register ? `<div class="row"><span class="label"><i class="fas fa-calendar"></i> Ngày đăng ký</span><span class="value">${d.register}</span></div>` : ''}
    </div>
`;
    

const top = d.top_skins || [];
if (top.length > 0) {
    html += `
        <div class="result-card" style="padding: 16px 18px;">
            <div style="display:flex;align-items:center;gap:10px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:10px;">
                <i class="fas fa-star" style="color:var(--gold);font-size:15px;"></i>
                <span style="font-weight:700;color:#fff;font-size:14px;">Skin nổi bật</span>
                <span style="font-size:11px;color:#64748b;background:rgba(255,255,255,0.05);padding:1px 10px;border-radius:12px;">${top.length} skin</span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill, minmax(200px, 1fr));gap:8px;">
    `;
    
    top.slice(0, 20).forEach(s => {
        const cls = (s.tier || 'Thường').toLowerCase();
        const name = s.skin_name || s.name || 'Skin';
        const hero = s.hero_name || '';
        const avatar = s.skin_avatar || s.avatar || '';
        
        // Lấy màu cho border theo tier
        let borderColor = 'rgba(255,255,255,0.08)';
        let glowColor = 'transparent';
        if (cls === 'sss') { borderColor = 'rgba(245,158,11,0.3)'; glowColor = 'rgba(245,158,11,0.05)'; }
        else if (cls === 'anime') { borderColor = 'rgba(236,72,153,0.3)'; glowColor = 'rgba(236,72,153,0.05)'; }
        else if (cls === 'ss') { borderColor = 'rgba(56,189,248,0.3)'; glowColor = 'rgba(56,189,248,0.05)'; }
        
        html += `
            <div style="display:flex;align-items:center;gap:10px;background:rgba(255,255,255,0.03);border:1px solid ${borderColor};border-radius:10px;padding:8px 12px 8px 8px;transition:all 0.25s ease;cursor:default;position:relative;"
                 onmouseover="this.style.borderColor='var(--main)';this.style.background='rgba(0,255,136,0.06)';this.style.transform='translateY(-2px)';this.style.boxShadow='0 4px 15px rgba(0,255,136,0.08)'"
                 onmouseout="this.style.borderColor='${borderColor}';this.style.background='rgba(255,255,255,0.03)';this.style.transform='translateY(0)';this.style.boxShadow='none'">
                ${avatar ? `<img src="${avatar}" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,0.08);flex-shrink:0;" onerror="this.style.display='none'">` : `<div style="width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;font-size:14px;color:#64748b;flex-shrink:0;font-weight:600;">${name.charAt(0)}</div>`}
                <div style="flex:1;min-width:0;">
                    <div style="font-size:13px;font-weight:600;color:#f1f5f9;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${name}</div>
                    ${hero ? `<div style="font-size:11px;color:var(--text-secondary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:1px;"><i class="fas fa-helmet-un" style="font-size:9px;color:var(--main);margin-right:4px;"></i>${hero}</div>` : ''}
                </div>
                <span class="skin-tag ${cls}" style="font-size:9px;padding:2px 10px;margin:0;flex-shrink:0;font-weight:700;border-radius:14px;">${cls}</span>
            </div>
        `;
    });
    
    if (d.total_skins > 20) {
        html += `
            <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(255,255,255,0.03);border:1px dashed rgba(255,255,255,0.1);border-radius:10px;padding:12px 8px;gap:2px;min-height:56px;">
                <span style="font-size:20px;font-weight:700;color:#64748b;">+${d.total_skins - 20}</span>
                <span style="font-size:10px;color:#64748b;">skin khác</span>
            </div>
        `;
    }
    
    html += `
            </div>
        </div>
    `;
}
    

    if (heroesData.length > 0) {
        html += `
            <div class="result-card">
                <div class="hero-section-header">
                    <i class="fas fa-helmet-un"></i>
                    Danh sách Tướng (${heroesData.length})
                    <span>(Bấm để xem skin)</span>
                </div>
                <div class="hero-grid" id="heroGrid">
        `;
        
        heroesData.forEach((h, i) => {
            const avatar = h.avatar || '';
            const name = h.name || 'Unknown';
            const skinCount = h.skins ? h.skins.length : 0;
            html += `
                <div class="hero-item" onclick="toggleSkins(${i})" id="hero_${i}">
                    ${avatar ? `<img src="${avatar}" onerror="this.style.display='none'">` : `<div style="width:50px;height:50px;border-radius:50%;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;font-size:18px;color:#64748b;font-weight:bold;">${name.charAt(0)}</div>`}
                    <span class="hero-name">${name}</span>
                    <span class="skin-count">${skinCount} skin</span>
                </div>
            `;
        });
        
        html += `</div><div id="skinContainer"></div></div>`;
    }
    

    if (d.sso || d.access || d.session || d.openid) {
        html += `
            <div class="token-toggle" onclick="toggleToken()" id="tokenToggle">
                <span><i class="fas fa-key"></i> Mã Token</span>
                <i class="fas fa-chevron-down"></i>
            </div>
            <div id="tokenDrawer">
                ${d.sso ? `<div class="token-row"><span class="token-label">SSO Key</span><span class="token-value">${d.sso}</span><button class="btn-copy" onclick="copyText('${d.sso}')">Copy</button></div>` : ''}
                ${d.access ? `<div class="token-row"><span class="token-label">Access Token</span><span class="token-value">${d.access}</span><button class="btn-copy" onclick="copyText('${d.access}')">Copy</button></div>` : ''}
                ${d.session ? `<div class="token-row"><span class="token-label">Session Token</span><span class="token-value">${d.session}</span><button class="btn-copy" onclick="copyText('${d.session}')">Copy</button></div>` : ''}
                ${d.openid ? `<div class="token-row"><span class="token-label">Open ID</span><span class="token-value">${d.openid}</span><button class="btn-copy" onclick="copyText('${d.openid}')">Copy</button></div>` : ''}
            </div>
        `;
    }
    
    $('#result').html(html);
    $('#result').show();
}

function showSkinList(type, count) {
    if (count === 0) {
        Swal.fire({
            icon: 'info',
            title: 'Trống',
            text: `Không có skin nào trong danh mục này!`,
            background: '#111827',
            color: '#fff'
        });
        return;
    }
    

    document.querySelectorAll('.category-item').forEach(el => el.classList.remove('active'));
    

    document.querySelectorAll('.category-item').forEach(el => {
        if (el.classList.contains(type)) {
            el.classList.add('active');
        }
    });
    
    const container = document.getElementById('skinListContainer');
    let html = '';
    

    if (container.classList.contains('open') && container.dataset.type === type) {
        container.classList.remove('open');
        container.dataset.type = '';
        document.querySelectorAll('.category-item').forEach(el => el.classList.remove('active'));
        return;
    }
    
    let skinList = [];
    let title = '';
    let icon = '';
    
    switch(type) {
        case 'all':
            skinList = allSkinsData;
            title = 'Tất cả Skin';
            icon = '📊';
            break;
        case 'sss':
            skinList = sssList;
            title = 'Skin SSS';
            icon = '⭐';
            break;
        case 'anime':
            skinList = animeList;
            title = 'Skin Anime';
            icon = '🎭';
            break;
        case 'ss':
            skinList = ssList;
            title = 'Skin SS';
            icon = '💎';
            break;
        case 'normal':
            const sssNames = new Set(sssList.map(s => s.skin_name || s.name));
            const animeNames = new Set(animeList.map(s => s.skin_name || s.name));
            const ssNames = new Set(ssList.map(s => s.skin_name || s.name));
            skinList = allSkinsData.filter(s => {
                const name = s.skin_name || s.name;
                return !sssNames.has(name) && !animeNames.has(name) && !ssNames.has(name);
            });
            title = 'Áo Thường';
            icon = '👕';
            break;
        case 'hero':
            if (heroesData.length === 0) {
                html = `<div class="skin-list-empty">Không có dữ liệu tướng</div>`;
            } else {
                html = `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;padding:4px 0;">`;
                heroesData.forEach(h => {
                    const avatar = h.avatar || '';
                    const name = h.name || 'Unknown';
                    const skinCount = h.skins ? h.skins.length : 0;
                    html += `
                        <div style="display:flex;flex-direction:column;align-items:center;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:10px 4px;transition:0.3s;cursor:pointer;" onclick="toggleSkins(${heroesData.indexOf(h)})">
                            ${avatar ? `<img src="${avatar}" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,0.06);" onerror="this.style.display='none'">` : `<div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;font-size:18px;color:#64748b;font-weight:bold;">${name.charAt(0)}</div>`}
                            <span style="font-size:11px;color:#cbd5e1;font-weight:600;margin-top:4px;text-align:center;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${name}</span>
                            <span style="font-size:9px;color:#64748b;">${skinCount} skin</span>
                        </div>
                    `;
                });
                html += `</div>`;
            }
            container.innerHTML = html;
            container.dataset.type = type;
            container.classList.add('open');
            return;
        default:
            return;
    }
    
    if (skinList.length === 0) {
        html = `<div class="skin-list-empty">Không có skin nào trong danh mục này</div>`;
    } else {
        html = `
            <div class="skin-list-header">
                <span class="title">${icon} ${title}</span>
                <span class="count">${skinList.length} skin</span>
            </div>
        `;
        
        skinList.forEach(s => {
            const name = s.skin_name || s.name || 'Skin';
            const hero = s.hero_name || '';
            const tier = s.tier || 'Thường';
            const avatar = s.skin_avatar || s.avatar || '';
            
            html += `
                <div class="skin-item">
                    ${avatar ? `<img class="skin-avatar" src="${avatar}" onerror="this.style.display='none'">` : `<div class="skin-avatar" style="display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.05);font-size:20px;color:#64748b;">${name.charAt(0)}</div>`}
                    <div class="skin-info">
                        <span class="skin-name">${name}</span>
                        ${hero ? `<span class="skin-hero"><i class="fas fa-helmet-un"></i> ${hero}</span>` : ''}
                    </div>
                    <span class="skin-tier ${tier}">${tier}</span>
                </div>
            `;
        });
    }
    
    container.innerHTML = html;
    container.dataset.type = type;
    container.classList.add('open');
    container.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function toggleSkins(index) {
    const hero = heroesData[index];
    if (!hero) return;
    
    const items = document.querySelectorAll('.hero-item');
    items.forEach((el, i) => {
        if (i === index) el.classList.toggle('active');
        else el.classList.remove('active');
    });
    
    const container = document.getElementById('skinContainer');
    const existing = document.getElementById('skinDetail');
    
    if (existing && existing.dataset.index == index) {
        existing.remove();
        return;
    }
    
    if (existing) existing.remove();
    const skins = hero.skins || [];
    if (skins.length === 0) {
        container.innerHTML = `<div class="hero-skins open"><div style="text-align:center;color:#64748b;padding:12px;">Không có skin</div></div>`;
        return;
    }
    
    let html = `<div class="hero-skins open" id="skinDetail" data-index="${index}">
        <div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:6px;border-bottom:1px solid rgba(255,255,255,0.05);margin-bottom:6px;">
            <span style="font-weight:600;color:#fff;font-size:14px;">${hero.name}</span>
            <span style="font-size:11px;color:#64748b;">${skins.length} skin</span>
        </div>`;
    
    skins.forEach(s => {
        const tier = s.tier || 'Thường';
        const name = s.name || 'Skin';
        const avatar = s.avatar || '';
        html += `
            <div class="skin-item">
                ${avatar ? `<img src="${avatar}" onerror="this.style.display='none'">` : `<div style="width:36px;height:36px;border-radius:8px;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;color:#64748b;font-size:12px;">${name.charAt(0)}</div>`}
                <span class="skin-name">${name}</span>
                <span class="skin-tier ${tier}">${tier}</span>
            </div>
        `;
    });
    
    html += `</div>`;
    container.innerHTML = html;
    const detail = document.getElementById('skinDetail');
    if (detail) detail.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function toggleToken() {
    const drawer = $('#tokenDrawer');
    const toggle = $('#tokenToggle');
    drawer.toggleClass('open');
    toggle.toggleClass('open');
}

function copyText(text) {
    if (!text) {
        Swal.fire({ icon: 'warning', title: 'Không có dữ liệu', background: '#111827', color: '#fff' });
        return;
    }
    navigator.clipboard.writeText(text).then(() => {
        Swal.fire({ icon: 'success', title: 'Đã sao chép!', timer: 1200, showConfirmButton: false, background: '#111827', color: '#fff' });
    }).catch(() => {
        const ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        Swal.fire({ icon: 'success', title: 'Đã sao chép!', timer: 1200, showConfirmButton: false, background: '#111827', color: '#fff' });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    const saved = localStorage.getItem('aov_user');
    if (saved) $('#username').val(saved);
    $('#username').on('change', function() {
        localStorage.setItem('aov_user', $(this).val().trim());
    });
});
</script>

